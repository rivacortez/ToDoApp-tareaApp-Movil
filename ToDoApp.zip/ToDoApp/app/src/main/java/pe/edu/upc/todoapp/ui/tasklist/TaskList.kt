package pe.edu.upc.todoapp.ui.tasklist

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun TaskList(
    tasks: List<String> = emptyList(),
    onSelectTask: (Int) -> Unit = {},
    onAddTask: () -> Unit = {}
) {

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { onAddTask() }) {
                Icon(Icons.Filled.Add, contentDescription = "Add")
            }
        }
    ) { paddingValues ->
        LazyColumn(modifier = Modifier.padding(paddingValues)) {
            itemsIndexed(tasks) { index,task ->
                Card(onClick = {
                    onSelectTask(index)
                }, modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)) {
                    Text(text = task, modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp))
                }

            }
        }
    }

}

@Preview
@Composable
fun TaskListPreview() {
    TaskList()
}
